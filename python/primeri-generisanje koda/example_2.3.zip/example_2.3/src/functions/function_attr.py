NAME = "name"
RETURN_TYPE = "return_type"
INCLUDE = "include"
PARAMETERS = 'parameters'
TYPE = 'type'
PASSING_BY_VALUE = 'passing_by_value'

