import os

TEMPLATES_ROOT = os.path.join(os.path.dirname(__file__), "templates")
DESTINATION = os.path.join(os.path.dirname(__file__), "c_project")
