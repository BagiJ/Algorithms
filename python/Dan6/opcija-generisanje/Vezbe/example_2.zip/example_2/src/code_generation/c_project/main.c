// generated using template: main.template
//---------------------------------------------------------------------------------

/*********************************************************************************
**
**  Module Name: main.c
**  Description:
**            Main file
** 
**  Author: Pera Petrovic
**  Date:   27.07.2014 05:50:04
**********************************************************************************

// generated using template: include.template
//---------------------------------------------------------------------------------
   
// generated using template: function_prototypes.template
//---------------------------------------------------------------------------------

float zbir();

float razlika();

float proizvod();

void stampa();

// generated using template: functions.template
//---------------------------------------------------------------------------------


float zbir() {

}

float razlika() {

}

float proizvod() {

}

void stampa() {

}

	
// generated using template: main_block.template
//---------------------------------------------------------------------------------


int main(int argc, char *argv[])
{
// To be implemented...

}