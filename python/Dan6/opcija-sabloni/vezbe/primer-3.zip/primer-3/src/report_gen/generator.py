# -*- coding: utf-8 -*-
#
# Basic example that shows the Jinja2 template engine usage.
# TODO: Extend example to support more types of test execution reporting
#

from jinja2.environment import Environment
from jinja2.loaders import FileSystemLoader

from os.path import (join as pt_join,
                     dirname,
                     exists)
from os import makedirs
import time
import random
import shutil

# Report generator configuration
TEMPLATES_ROOT = pt_join(dirname(__file__), "..", "templates")
DESTINATION = pt_join(dirname(__file__), "..", "report")
STYLES_FILE_NAME = "simple_style.css"

TEST_TITLES = [u"Validni ulazi",
               u"Nevalidni ulazi",
               u"Granične vrednosti",
               u"Reakcija na greške",
               u"Obavezne provere",
               u"Ostalo",
               u"Prekoračenje opsega"
               ]


class Report(object):
    """
    Report generator example no. 1: using static text and variables
    """

    def __init__(self, tester_name):
        """
        Constructor
        """
        self.output_file_name = ""
        self.tester_name = tester_name

    def generate_test_case_list(self):
        tests_list = list()
        for tc_id, tc_d in enumerate(TEST_TITLES):
            execution_time = time.strftime("%d.%m.%Y %H:%M:%S")
            tc_result = "OK" if tc_id % 3 != 0 else "NOK"
            c_test = {"title": tc_d,
                      "execution_time": execution_time,
                      "result": tc_result,
                      "description": "Testirnanje funkcije 'prikaz'",
                      "procedure": ("Poziv\n"
                                    "\tProvera vrednosti\n"
                                    "\tSpecificno za test %s" %
                                    tc_d.lower()),
                      "criteria": (u"Test je uspešan ukoliko vraćena vrednost "
                                   u"odgovara očekivanoj vrednosti za test "
                                   u"%s" %
                                   tc_d.lower()),
                      "num": tc_id + 1
                      }
            tests_list.append(c_test)
        return tests_list

    def generate(self, file_name):
        """
        Activates data streamint through template

        Args:
            file_name: name of a generated file
        Returns:
            True, if output is successfully generated, None otherwise
        """

        # create desination directory if not exist
        if not exists(DESTINATION):
            makedirs(DESTINATION)

        # copy styles
        css_src = pt_join(TEMPLATES_ROOT, STYLES_FILE_NAME)
        shutil.copy(css_src, DESTINATION)

        # dictionary for passing data to template engine:
        data = {}
        random.seed()
        data["rep_num"] = random.randint(1, 1000)
        tests_list = self.generate_test_case_list()
        data["tests"] = tests_list
        data["tester_name"] = self.tester_name
        data["stylesheet"] = STYLES_FILE_NAME

        # loader for templates from disk:
        # file_system_loader = FileSystemLoader([path1, path2, path3....])

        file_system_loader = FileSystemLoader([TEMPLATES_ROOT])

        destination_path = pt_join(DESTINATION, file_name)

        # setting environment for the template engine:
        env = Environment(loader=file_system_loader,
                          trim_blocks=True,
                          autoescape=True
                          )
        # getting the desired template
        template = env.get_template("main.template")
        # generate:
        template.stream(data).dump(destination_path)
        return True


def main():
    report_gen = Report(u"Petar Petrović")
    report_gen.generate("TE-izvestaj.html")


if __name__ == "__main__":
    main()
