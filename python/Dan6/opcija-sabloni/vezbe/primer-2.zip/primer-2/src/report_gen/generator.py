# -*- coding: utf:8 -*-
#
# Basic example that shows the Jinja2 template engine usage.
# TODO: Extend example to support more types of test execution reporting
#

from jinja2.environment import Environment
from jinja2.loaders import FileSystemLoader

from os.path import (join, dirname, exists)
from os import makedirs
import time
import random

# Report generator configuration
TEMPLATES_ROOT = join(dirname(__file__), "..", "templates")
DESTINATION = join(dirname(__file__), "..", "report")

TEST_TITLES = ["Validni ulazi",
               "Nevalidni ulazi",
               "Granicne vrednosti",
               "Reakcija na greske",
               "Obavezne provere",
               "Ostalo",
               "Prekoracenje opsega"
               ]


class Report(object):
    """
    Report generator example no. 1: using static text and variables
    """

    def __init__(self, tester_name):
        """
        Constructor
        """
        self.output_file_name = ""
        self.tester_name = tester_name

    def generate_test_case_list(self):
        tests_list = list()
        for tc_id, tc_d in enumerate(TEST_TITLES):
            execution_time = time.strftime("%d.%m.%Y %H:%M:%S")
            tc_result = "OK" if tc_id % 3 != 0 else "NOK"
            tc_result = "NE" if tc_id % 4 != 1 else tc_result
            c_test = {"title": tc_d,
                      "execution_time": execution_time,
                      "result": tc_result,
                      "description": "Testirnanje funkcije 'prikaz'",
                      "procedure": ("\t1. Poziv"
                                    "\\line \t2. Provera vrednosti"
                                    "\\line \t3. Specificno za test %s" %
                                    tc_d.lower()),
                      "criteria": ("Test je uspesan ukoliko vracena vrednost "
                                   "odgovara ocekivanoj vrednosti za test "
                                   "%s" %
                                   tc_d.lower()),
                      "num": tc_id + 1
                      }
            tests_list.append(c_test)
        return tests_list

    def generate(self, file_name):
        """
        Activates data streamint through template

        Args:
            file_name: name of a generated file
        Returns:
            True, if output is successfully generated, None otherwise
        """

        destination_path = join(DESTINATION, file_name)

        # create desination directory if not exist
        if not exists(DESTINATION):
            makedirs(DESTINATION)

        # dictionary for passing data to template engine:
        data = {}
        random.seed()
        data["rep_num"] = random.randint(1, 1000)
        tests_list = self.generate_test_case_list()
        data["tests"] = tests_list
        data["tester_name"] = self.tester_name

        # generate:
        # loader for templates from disk:
        # file_system_loader = FileSystemLoader([path1, path2, path3....])

        file_system_loader = FileSystemLoader([TEMPLATES_ROOT])

        # setting environment for the template engine:
        env = Environment(loader=file_system_loader,
                          trim_blocks=True,
                          autoescape=False
                          )

        # getting the desired template
        template = env.get_template("izvestaj.template")
        template.stream(data).dump(destination_path)
        return True


def main():
    report_gen = Report("Petar Petrovic")
    report_gen.generate("TE-izvestaj.rtf")


if __name__ == "__main__":
    main()
