# =*- coding: utf:8 -*-
#
# Basic example that shows the Jinja2 template engine usage.
# TODO: Extend example to support the tester information
#

from jinja2.environment import Environment
from jinja2.loaders import FileSystemLoader

from os.path import (join, basename, dirname, exists)
from os import makedirs
import time
import random

# Report generator configuration
TEMPLATES_ROOT = join(dirname(__file__), "..", "templates")
DESTINATION = join(dirname(__file__), "..", "report")


class Report(object):
    """
    Report generator example no. 1: using static text and variables
    """

    def __init__(self):
        """
        Constructor
        """

    def generate(self, file_name):
        """
        Activates data streamint through template

        Args:
            file_name: name of a generated file
        Returns:
            True, if output is successfully generated, None otherwise
        """

        # loader for templates from disk:
        # file_system_loader = FileSystemLoader([path1, path2, path3....])

        file_system_loader = FileSystemLoader([TEMPLATES_ROOT])

        destination_path = join(DESTINATION, file_name)

        # create desination directory if not exist
        if not exists(DESTINATION):
            makedirs(DESTINATION)

        # setting environment for the template engine:
        env = Environment(loader=file_system_loader,
                          trim_blocks=True,
                          autoescape=False
                          )

        # getting the desired template
        template = env.get_template("izvestaj.template")

        # dictionary for passing data to template engine:
        data = {}
        random.seed()
        data["rep_num"] = random.randint(1, 1000)
        execution_time = time.strftime("%d.%m.%Y %H:%M:%S")
        data["tests"] = [
            {"title": "Validan izlaz",
             "execution_time": execution_time,
             "result": "OK",
             "description": "Testiranje valdinih ulaza funkcije 'prikaz'",
             "procedure": ("\\line \t1. Poziv"
                           "\\line \t2. Provera vrednosti"),
             "criteria": ("Test je uspesan ukoliko vracena vrednost "
                          "odgovara ocekivanoj"),
             "num": 1
             }
            ]
        # TODO: Add anoter test here ...
        b = data["tests"][0].copy()
        data["tests"].append(b)
        data["tests"][1]["num"] = 2

        # generate .rtf report:
        template.stream(data).dump(destination_path)

        return True


def main():
    report_gen = Report()
    report_gen.generate("TE-izvestaj.rtf")


if __name__ == "__main__":
    main()
